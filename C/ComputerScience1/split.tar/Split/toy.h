#include <stdio.h>
#include <stdlib.h>

int dig();
char let();


